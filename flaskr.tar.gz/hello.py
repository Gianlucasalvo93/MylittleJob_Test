from flask import Flask, render_template
app = Flask(__name__)
from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash, _app_ctx_stack,make_response


import requests,json

#build id...root,parameters.....

global types
@app.route('/get_api', methods=['GET', 'POST'])
def get_api():


    import urllib2
    global types
    title = request.form['search']


    print types
    raw_content = urllib2.urlopen("https://api.spotify.com/v1/search?q="+str(title)+"&type="+types).read()
    #raw_content = urllib2.urlopen("https://api.spotify.com/v1/search?q=Bob&type=artist&limit=2&offset=20").read()
    json_content=json.loads(raw_content)

    artist= json_content[types+"s"]["items"]
    print len(artist)
    return render_template('index.html',content=artist,counter=len(artist))

@app.route('/set_type_artist')
def set_type_artist():
    global types
    types="artist"
    return render_template('index_w_b.html')

@app.route('/set_type_album')
def set_type_album():
    global types
    types="album"
    return render_template('index_w_b.html')
@app.route('/set_type_playlist')
def set_type_playlist():
    global types
    types="playlist"
    return render_template('index_w_b.html')
@app.route('/set_type_track')
def set_type_track():
    global types
    types="track"
    return render_template('index_w_b.html')
    
'''
@app.route('/login0', methods=['GET', 'POST'])
def login0():
    error = None
    if request.method == 'POST':
        user=request.form['username']
	psw=request.form['password']
	store_login(user,psw)
	global ses
	ses=True
        return redirect(url_for('hello'))
    return render_template('login.html', error=error)




def store_login(user,psw):
    f = open("cred","w")
    alll=user+psw
    f.write(alll)  

'''

@app.route("/")
def hello():
    #return redirect(url_for('login0'))
    return render_template('index.html',counter=0)




'''
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = int(request.form['username1'])
	num2 = int(request.form['username2'])
        if username:
            print request.form
            #flash('You were logged in')
	    global ses,ris
	    ses=True
	    ris=username+num2
	    print "fatto"
            return redirect(url_for('hello'))
        else:
            flash("You must provide a username")
    return render_template('link1.html', error=error)

'''

if __name__ == "__main__":
    app.run()
